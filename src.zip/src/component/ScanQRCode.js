import React, { useState } from "react";
import { useDropzone } from "react-dropzone";
import "./ScanQRCode.css";

export default function ScanQRCode() {
    const [decodedData, setDecodedData] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [birthDate, setBirthDate] = useState("");
    const [gender, setGender] = useState("");
    const [startDate, setStartDate] = useState("");
    const [organization, setOrganization] = useState("");
    const [location, setLocation] = useState("");
    const [jobTitle, setJobTitle] = useState("");
    const [department, setDepartment] = useState("");
  
    const onDrop = (acceptedFiles) => {
      const file = acceptedFiles[0];
      const formData = new FormData();
      formData.append("file", file);
  
      fetch("http://localhost:8080/api/employees/read_qrcode", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          setDecodedData(data);
          setFirstName(data.firstName);
          setLastName(data.lastName);
          setEmail(data.email);
          setBirthDate(data.birthDate);
          setGender(data.gender);
          setStartDate(data.startDate);
          setOrganization(data.organization);
          setLocation(data.location);
          setJobTitle(data.jobTitle);
          setDepartment(data.department);
        })
        .catch((error) => {
          console.error("Error decoding QR code:", error);
        });
    };
  
    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });
  
    return (
      <div>
        <h1>QR Code Reader</h1>
        <div {...getRootProps()} className="dropzone">
          <input {...getInputProps()} />
          {isDragActive ? (
            <p>Drop the QR Code image here ...</p>
          ) : (
            <p>Drag and drop a PNG QR code image</p>
          )}
        </div>
        {decodedData && (
          <div>
            <h2>Decoded information:</h2>
            <ul>
              <li>First Name: {firstName}</li>
              <li>Last Name: {lastName}</li>
              <li>Email: {email}</li>
              <li>Birth Date: {birthDate}</li>
              <li>Gender: {gender}</li>
              <li>Start Date: {startDate}</li>
              <li>Organization Name: {organization}</li>
              <li>Location Name: {location}</li>
              <li>Job Title: {jobTitle}</li>
              <li>Department: {department}</li>
            </ul>
          </div>
        )}
      </div>
    );
  }
